/* network functions */
int openSocket(char *const hostname,unsigned short remoteport_num);
