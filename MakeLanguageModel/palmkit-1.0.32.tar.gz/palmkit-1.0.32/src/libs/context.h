#include "slm.h"

SLMHashTable *readContextCues(SLMNgram *ng, char *file);

